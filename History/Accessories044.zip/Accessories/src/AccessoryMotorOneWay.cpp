/*************************************************************
project: <Accessories>
author: <Thierry PARIS>
description: <Class for a one way motorized accessory>
*************************************************************/

#include "Accessories.h"

