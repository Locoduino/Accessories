var searchData=
[
  ['servo',['servo',['../classPortServo.html#a892b529df0ad7376695f9414e6fea5db',1,'PortServo']]],
  ['speed',['speed',['../classPort.html#a8a53f78f0221c753527a92cb9cb0f68f',1,'Port']]]
];
