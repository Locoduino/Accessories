//-------------------------------------------------------------------
#ifndef __portexpandersx1509_H__
#define __portexpandersx1509_H__
//-------------------------------------------------------------------

#ifndef NO_EXPANDER_SX1509

#include "PortExpander.hpp"
#include <Wire.h> // Include the I2C library (required)
#include "SparkFunSX1509.h" // Include SX1509 library

/** This class describes a SX1509 circuit as an expander: a circuit which provides 16 outputs 
digital or analog. Each expander is identified by a number : the id.
Only output pins are used in Accessories. This expander can provide digital and analog (pwm) output.*/
class PortExpanderSX1509 : public PortExpander
{
	private:
		SX1509 sx1509; // Create an SX1509 object to be used throughout

	public:
		/** Initialize the instance of the expander.
		@param inId					id of expander (to be used associated to pin).
		@param inAddress		I2C address used to communicate.
		@return True if the connection has been established, otherwise false.
		*/
		byte begin(int inId, byte inAddress);
		/** Initialize one pin of the expander.
		@param inPin number of the pin. should be between 0 and 15.
		@param inType type of the output of this pin : only DIGITAL or ANALOG here.
		*/
		void beginPin(int inPin, PIN_TYPE inType);
		/** Set the state of one pin of the expander.
		@param inPin number of the pin. should be between 0 and the maximum number of expander pins.
		@param inValue New state of the pin. Should be HIGH (1) or LOW (0).
		*/
		void digitalWrite(int inPin, int inValue);
		/** Set the value of one pin of the expander.
		@param inPin number of the pin. should be between 0 and the maximum number of expander pins.
		@param inValue New analog value of the pin. Should be between 0 and 255.
		*/
		void analogWrite(int inPin, int inValue);

	public:
		/**Default constructor.*/
		PortExpanderSX1509();
};

//-------------------------------------------------------------------
#endif
#endif
//-------------------------------------------------------------------
