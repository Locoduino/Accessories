//-------------------------------------------------------------------
#ifndef __AccessoriesEventStack_Hpp__
#define __AccessoriesEventStack_Hpp__
//-------------------------------------------------------------------

#include <Accessories.h>

// Commanders dont have need for more events at this moment : more events, more memory consumed !
// A debug message will be shown if an event is lost because of this tiny size !
#define ACCESSSORIES_EVENT_MAXNUMBER	3

/** The event stack is a small location for a few events ready to be send to the caller.
This is a barely a list. The defined events are always from index 0 to the last defined.
Each PushEvent will be push the new one at the end of the list.
Each GetEvent will always returns the first element of the list at index 0. If index 0 has its id at UNDEFINED_ID,
so the list is empty...
With this structure, this is a FIFO stack.

Function call  | 0   | 1    | 2
---------------|-----|------|------
empty list     |undef| undef|undef
PushEvent A    | A   | undef|undef
PushEvent B    | A   | B    |undef
GetEvent       | B   | undef|undef

*/
class AccessoriesEventStack
{
private:
	unsigned long id[ACCESSSORIES_EVENT_MAXNUMBER];
	ACCESSORIES_EVENT_TYPE type[ACCESSSORIES_EVENT_MAXNUMBER];
	int data[ACCESSSORIES_EVENT_MAXNUMBER];

	AccessoriesEventStack()
	{
		for (byte i = 0; i < ACCESSSORIES_EVENT_MAXNUMBER; i++)
			FreeEvent(i);
	}

	void FreeEvent(byte inEvent); 

public:
	/** Stack of events itself.*/
	static AccessoriesEventStack EventsStack;

	/** Add a new event	to the stack.
	@param inId		id of the event
	@param inType	type
	@param inData	associated data
	*/
	void PushEvent(unsigned long inId, ACCESSORIES_EVENT_TYPE inType, int inData);
	/** Gets an event from the stack.
	@param inpId	address to fill with the id of the event or UNDEFINED_ID if no event is available.
	@param inpType	address to fill with the type
	@param inpData	address to fill with the associated data
	@remark A previous call to GetPendingEventIndex() will give the first available event index.
	*/
	void GetEvent(unsigned long *inpId, ACCESSORIES_EVENT_TYPE *inpType, int *inpData);
	/** Gets the first free event index in the stack.
	@return index of the first free event in the list.
	*/
	byte GetFreeEventIndex();
};


#endif