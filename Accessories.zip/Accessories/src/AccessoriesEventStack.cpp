#ifdef VISUALSTUDIO
#include "string.h"
#endif

#include "AccessoriesEventStack.hpp"

AccessoriesEventStack AccessoriesEventStack::EventsStack;

void AccessoriesEventStack::FreeEvent(byte inEvent)
{
	id[inEvent] = UNDEFINED_ID;
	type[inEvent] = ACCESSORIES_EVENT_NONE;
	data[inEvent] = 0; 
}

void AccessoriesEventStack::PushEvent(unsigned long inId, ACCESSORIES_EVENT_TYPE inType, int inData)
{
	for (int i =0; i < ACCESSSORIES_EVENT_MAXNUMBER; i++)
		if (this->id[i] == UNDEFINED_ID)
		{
			this->id[i] = inId;
			this->type[i] = inType;
			this->data[i] = inData;
			return;
		}

#ifdef COMMANDERS_DEBUG_MODE
	Serial.println(F("Error : an event has been lost ! Stack is full !"));
#endif
}

byte AccessoriesEventStack::GetFreeEventIndex()
{
	for (int i = 0; i < ACCESSSORIES_EVENT_MAXNUMBER; i++)
		if (this->id[i] == UNDEFINED_ID)
			return i;

	return 255;
}

void AccessoriesEventStack::GetEvent(unsigned long *inpId, ACCESSORIES_EVENT_TYPE *inpType, int *inpData)
{
	if (this->id[0] == UNDEFINED_ID)
		return;

	*inpId = this->id[0];
	*inpType = this->type[0];
	*inpData = this->data[0];

	memmove(this->id, this->id + 1, sizeof(unsigned long));
	memmove(this->type, this->type + 1, sizeof(ACCESSORIES_EVENT_TYPE));
	memmove(this->data, this->data + 1, sizeof(int));

	this->id[ACCESSSORIES_EVENT_MAXNUMBER - 1] = UNDEFINED_ID;
}
