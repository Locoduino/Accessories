#define ARDUINO_ARCH_AVR
#define ARDUINO_AVR_MEGA
#define __AVR_ATmega2560__
