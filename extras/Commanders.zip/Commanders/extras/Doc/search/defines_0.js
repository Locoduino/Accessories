var searchData=
[
  ['commanders_5fdebug_5fmode',['COMMANDERS_DEBUG_MODE',['../Commanders_8h.html#a1fdf52a0fdf8778a4472686eaa278b15',1,'Commanders.h']]],
  ['commanders_5fdebug_5fverbose_5fmode',['COMMANDERS_DEBUG_VERBOSE_MODE',['../Commanders_8h.html#a43b270926f3753345583c1ed6f03c831',1,'Commanders.h']]],
  ['commanders_5fprint_5fcommanders',['COMMANDERS_PRINT_COMMANDERS',['../Commanders_8h.html#a903f43d89a21cb3955b4fac654f6f8e8',1,'Commanders.h']]]
];
