#define COMMANDERS_DEBUG_MODE
#define COMMANDERS_PRINT_COMMANDERS

#include "../src/Commanders.h"